export declare class SavedCommand {
    quantity: number;
    potentialItemNames: string[];
    locale: string;
    constructor(quantity: number, potentialItemNames: string[], locale: string);
}

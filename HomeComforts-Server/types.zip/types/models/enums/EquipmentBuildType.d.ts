export declare enum EquipmentBuildType {
    CUSTOM = 0,
    STANDARD = 1
}

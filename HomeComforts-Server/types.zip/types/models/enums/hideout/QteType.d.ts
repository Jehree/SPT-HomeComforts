export declare enum QteType {
    SHRINKING_CIRCLE = 0
}

export declare enum QteEffectType {
    FINISH_EFFECT = "finishEffect",
    SINGLE_SUCCESS_EFFECT = "singleSuccessEffect",
    SINGLE_FAIL_EFFECT = "singleFailEffect"
}

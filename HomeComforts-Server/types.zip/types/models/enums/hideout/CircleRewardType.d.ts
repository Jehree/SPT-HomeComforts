export declare enum CircleRewardType {
    RANDOM = 0,
    HIDEOUT_TASK = 1
}

export declare enum QteActivityType {
    GYM = 0
}

export declare enum GiftSentResult {
    FAILED_UNKNOWN = 1,
    FAILED_GIFT_ALREADY_RECEIVED = 2,
    FAILED_GIFT_DOESNT_EXIST = 3,
    SUCCESS = 4
}

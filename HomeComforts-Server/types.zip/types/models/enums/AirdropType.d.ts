export declare enum AirdropTypeEnum {
    COMMON = "Common",
    SUPPLY = "Supply",
    MEDICAL = "Medical",
    WEAPON_ARMOR = "Weapon"
}
export declare enum SptAirdropTypeEnum {
    COMMON = "mixed",
    SUPPLY = "barter",
    FOOD_MEDICAL = "foodMedical",
    WEAPON_ARMOR = "weaponArmor",
    RADAR = "radar"
}

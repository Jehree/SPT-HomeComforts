export declare enum ItemAddedResult {
    UNKNOWN = -1,
    SUCCESS = 1,
    NO_SPACE = 2,
    NO_CONTAINERS = 3,
    INCOMPATIBLE_ITEM = 4
}

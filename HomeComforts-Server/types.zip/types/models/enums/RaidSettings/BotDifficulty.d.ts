export declare enum BotDifficulty {
    AS_ONLINE = "AsOnline",
    EASY = "Easy",
    MEDIUM = "Medium",
    HARD = "Hard",
    IMPOSSIBLE = "Impossible",
    RANDOM = "Random"
}

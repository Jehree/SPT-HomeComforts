export declare enum BotAmount {
    AS_ONLINE = "AsOnline",
    NO_BOTS = "NoBots",
    LOW = "Low",
    MEDIUM = "Medium",
    HIGH = "High",
    HORDE = "Horde"
}

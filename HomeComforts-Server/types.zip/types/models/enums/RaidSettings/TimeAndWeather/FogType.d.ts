export declare enum FogType {
    NO_FOG = "NoFog",
    FAINT = "Faint",
    FOG = "Fog",
    HEAVY = "Heavy",
    CONTINUOUS = "Continuous"
}

export declare enum RainType {
    NO_RAIN = "NoRain",
    DRIZZLING = "Drizzling",
    RAIN = "Rain",
    HEAVY = "Heavy",
    SHOWER = "Shower"
}

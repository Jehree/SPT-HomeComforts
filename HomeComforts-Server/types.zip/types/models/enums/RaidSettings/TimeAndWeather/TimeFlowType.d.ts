export declare enum TimeFlowType {
    X0 = "x0",
    X0_14 = "x0_14",
    X0_25 = "x0_25",
    X0_5 = "x0_5",
    X1 = "x1",
    X2 = "x2",
    X4 = "x4",
    X8 = "x8"
}

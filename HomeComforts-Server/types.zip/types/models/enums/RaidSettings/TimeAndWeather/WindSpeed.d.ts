export declare enum WindSpeed {
    LIGHT = "Light",
    MODERATE = "Moderate",
    STRONG = "Strong",
    VERY_STRONG = "VeryStrong",
    HURRICANE = "Hurricane"
}

export declare enum DogtagExchangeSide {
    USEC = "Usec",
    BEAR = "Bear",
    ANY = "Any"
}

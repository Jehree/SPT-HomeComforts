export declare enum DateTime {
    CURR = "CURR",
    PAST = "PAST"
}

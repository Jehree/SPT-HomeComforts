export declare enum FleaOfferType {
    SINGLE = 0,
    MULTI = 1,
    PACK = 2,
    UNKNOWN = 3
}

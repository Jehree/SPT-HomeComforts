export declare enum SideType {
    PMC = "Pmc",
    SAVAGE = "Savage",
    RANDOM = "Random"
}

export interface IRoute {
    spt: any;
}

export interface IItemSpawnLimitSettings {
    currentLimits: Record<string, number>;
    globalLimits: Record<string, number>;
}

export interface IBaseConfig {
    kind: string;
}
export interface IRunIntervalValues {
    inRaid: number;
    outOfRaid: number;
}

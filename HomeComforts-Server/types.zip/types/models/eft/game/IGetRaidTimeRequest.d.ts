export interface IGetRaidTimeRequest {
    Side: string;
    Location: string;
}

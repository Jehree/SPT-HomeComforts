export interface ISendReportRequest {
    type: string;
    uid: string;
}

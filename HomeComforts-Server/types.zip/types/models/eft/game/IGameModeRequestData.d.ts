export interface IGameModeRequestData {
    sessionMode: string | undefined;
}

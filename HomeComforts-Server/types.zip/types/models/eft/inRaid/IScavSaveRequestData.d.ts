import { IPostRaidPmcData } from "@spt/models/eft/common/IPmcData";
export interface IScavSaveRequestData extends IPostRaidPmcData {
}

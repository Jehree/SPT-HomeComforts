export interface INullResponseData {
    err: number;
    errmsg: any;
    data: undefined;
}

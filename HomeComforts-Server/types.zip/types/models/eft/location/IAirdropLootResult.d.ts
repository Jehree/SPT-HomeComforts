import { ILootItem } from "@spt/models/spt/services/LootItem";
export interface IAirdropLootResult {
    dropType: string;
    loot: ILootItem[];
}

export interface ICreateGroupMailRequest {
    Name: string;
    Users: string[];
}

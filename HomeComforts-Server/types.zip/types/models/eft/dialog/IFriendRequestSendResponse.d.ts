export interface IFriendRequestSendResponse {
    status: number;
    requestId: string;
    retryAfter: number;
}

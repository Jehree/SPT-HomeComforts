export interface IRemoveUserGroupMailRequest {
    dialogId: string;
    uid: string;
}

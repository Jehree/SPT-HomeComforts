export interface IDeleteFriendRequest {
    friend_id: string;
}

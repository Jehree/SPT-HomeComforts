export interface IGetMailDialogListRequestData {
    limit: number;
    offset: number;
}

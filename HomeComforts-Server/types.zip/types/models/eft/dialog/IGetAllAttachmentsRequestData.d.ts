export interface IGetAllAttachmentsRequestData {
    dialogId: string;
}

export interface IMatchGroupPlayerRemoveRequest {
    aidToKick: string;
}

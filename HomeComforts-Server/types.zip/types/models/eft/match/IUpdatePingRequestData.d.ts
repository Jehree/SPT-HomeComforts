export interface IUpdatePingRequestData {
    servers: any[];
}

export interface IRequestIdRequest {
    requestId: string;
}

export interface IServer {
    ping: number;
    ip: string;
    port: number;
}

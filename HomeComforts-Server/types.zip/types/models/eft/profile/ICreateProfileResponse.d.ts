export interface ICreateProfileResponse {
    uid: string;
}

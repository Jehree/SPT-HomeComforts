import { IItemEventRouterBase } from "@spt/models/eft/itemEvent/IItemEventRouterBase";
export interface IEmptyItemEventRouterResponse extends IItemEventRouterBase {
    profileChanges: "";
}

import { MinMax } from "@spt/models/common/MinMax";
export interface IGetItemPriceResult extends MinMax {
    avg: number;
}

export interface IGetRagfairOfferByIdRequest {
    id: number;
}

export interface IHideoutCircleOfCultistProductionStartRequestData {
    Action: "HideoutCircleOfCultistProductionStart";
    timestamp: number;
}

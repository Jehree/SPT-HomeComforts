export interface IHideoutSettingsBase {
    generatorSpeedWithoutFuel: number;
    generatorFuelFlowRate: number;
    airFilterUnitFlowRate: number;
    cultistAmuletBonusPercent: number;
    gpuBoostRate: number;
}

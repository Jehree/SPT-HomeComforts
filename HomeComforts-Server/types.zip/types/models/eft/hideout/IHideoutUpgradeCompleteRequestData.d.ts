export interface IHideoutUpgradeCompleteRequestData {
    Action: "HideoutUpgradeComplete";
    areaType: number;
    timestamp: number;
}

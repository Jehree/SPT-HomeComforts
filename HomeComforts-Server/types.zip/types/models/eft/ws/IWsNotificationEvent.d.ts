export interface IWsNotificationEvent {
    type: string;
    eventId?: string;
}

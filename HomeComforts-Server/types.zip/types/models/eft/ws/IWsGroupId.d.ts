import { IWsNotificationEvent } from "@spt/models/eft/ws/IWsNotificationEvent";
export interface IWsGroupId extends IWsNotificationEvent {
    groupId: string;
}

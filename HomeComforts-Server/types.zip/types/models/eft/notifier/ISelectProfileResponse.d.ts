export interface ISelectProfileResponse {
    status: string;
}

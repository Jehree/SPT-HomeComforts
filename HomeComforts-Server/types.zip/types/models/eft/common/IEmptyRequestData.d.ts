export type IEmptyRequestData = {};
